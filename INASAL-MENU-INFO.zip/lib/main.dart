import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;

void main() {
  runApp(MenuApp());
}

class MenuApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Mang Inasal Information Menu App',
      theme: ThemeData(
        primarySwatch: Colors.green,
      ),
      home: LoginScreen(),
    );
  }
}

class LoginScreen extends StatefulWidget {
  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  void _login() {
    String username = _usernameController.text;
    String password = _passwordController.text;

    if (username == 'User@gmail.com' && password == 'User') {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => MenuScreen()),
      );
    } else {
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text('Login Failed'),
            content: Text('Invalid username or password.'),
            actions: <Widget>[
              TextButton(
                child: Text('OK'),
                onPressed: () {
                  Navigator.of(context).pop();
                },
              ),
            ],
          );
        },
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Login'),
      ),
      body: Padding(
        padding: EdgeInsets.all(20.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            TextField(
              controller: _usernameController,
              decoration: InputDecoration(
                labelText: 'Username',
              ),
            ),
            SizedBox(height: 20.0),
            TextField(
              controller: _passwordController,
              obscureText: true,
              decoration: InputDecoration(
                labelText: 'Password',
              ),
            ),
            SizedBox(height: 20.0),
            ElevatedButton(
              onPressed: _login,
              child: Text('Login'),
            ),
          ],
        ),
      ),
    );
  }
}

class MenuScreen extends StatefulWidget {
  @override
  _MenuScreenState createState() => _MenuScreenState();
}

class _MenuScreenState extends State<MenuScreen> {
  List<MenuCategory> menuCategories = [];
  List<MenuItem> favoriteItems = [];
  int _currentIndex = 1;

  @override
  void initState() {
    super.initState();
    _loadMenuData();
  }

  Future<void> _loadMenuData() async {
    String jsonContent = await rootBundle.loadString('assets/menu.json');
    Map<String, dynamic> jsonData = json.decode(jsonContent);

    setState(() {
      menuCategories =
          List<MenuCategory>.from(jsonData['menu'].keys.map((categoryName) {
        List<MenuItem> items =
            (jsonData['menu'][categoryName] as List<dynamic>).map((itemData) {
          return MenuItem(
            name: itemData['name'],
            description: itemData['description'],
            price: itemData['price'].toDouble(),
            image: itemData['image'],
          );
        }).toList();

        return MenuCategory(categoryName: categoryName, items: items);
      }));
    });
  }

  void toggleFavorite(MenuItem item) {
    setState(() {
      if (favoriteItems.contains(item)) {
        favoriteItems.remove(item);
      } else {
        favoriteItems.add(item);
      }
    });
  }

  void navigateToDetailsScreen(MenuItem item) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => MenuItemDetailsScreen(item: item),
      ),
    );
  }

  void navigateToFavoritesScreen() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => FavoritesScreen(favoriteItems: favoriteItems),
      ),
    );
  }

  void onTabTapped(int index) {
    setState(() {
      _currentIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading:
            false, // Add this line to hide the back button
        title: Text('Mang Inasal Information food App'),
        actions: [
          IconButton(
            onPressed: navigateToFavoritesScreen,
            icon: Icon(Icons.favorite),
          ),
          IconButton(
            onPressed: () {
              Navigator.pushAndRemoveUntil(
                context,
                MaterialPageRoute(builder: (context) => LoginScreen()),
                (Route<dynamic> route) => false,
              );
            },
            icon: Icon(Icons.logout),
          ),
        ],
      ),
      body: _currentIndex == 0 // Show menu only when the "Menu" tab is selected
          ? menuCategories.isNotEmpty
              ? SingleChildScrollView(
                  padding: EdgeInsets.all(20.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      for (var category in menuCategories) ...[
                        MenuCategoryWidget(
                          categoryName: category.categoryName,
                          items: category.items,
                          toggleFavorite: toggleFavorite,
                          navigateToDetailsScreen: navigateToDetailsScreen,
                        ),
                        SizedBox(height: 20.0),
                      ],
                    ],
                  ),
                )
              : Center(
                  child: CircularProgressIndicator(),
                )
          : _currentIndex ==
                  1 // Show Mang Inasal home screen when the "Home" tab is selected
              ? HomeScreen()
              : _currentIndex == 2
                  ? FeedbackScreen() // Added HelloWorldScreen here
                  : Container(),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: onTabTapped,
        items: [
          BottomNavigationBarItem(
            icon: Icon(Icons.restaurant),
            label: 'Menu',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.sentiment_satisfied),
            label: 'Feedbacks',
          ),
        ],
      ),
    );
  }
}

class MenuCategory {
  final String categoryName;
  final List<MenuItem> items;

  MenuCategory({required this.categoryName, required this.items});
}

class MenuCategoryWidget extends StatelessWidget {
  final String categoryName;
  final List<MenuItem> items;
  final Function(MenuItem) toggleFavorite;
  final Function(MenuItem) navigateToDetailsScreen;

  MenuCategoryWidget({
    required this.categoryName,
    required this.items,
    required this.toggleFavorite,
    required this.navigateToDetailsScreen,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: EdgeInsets.symmetric(vertical: 10.0),
          child: Text(
            categoryName,
            style: TextStyle(
              fontSize: 20.0,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
        Column(
          children: items.map((item) {
            return GestureDetector(
              onTap: () => navigateToDetailsScreen(item),
              child: MenuItemCard(
                item: item,
                isFavorite: toggleFavorite,
              ),
            );
          }).toList(),
        ),
      ],
    );
  }
}

class MenuItem {
  final String name;
  final String description;
  final double price;
  final String image;

  MenuItem({
    required this.name,
    required this.description,
    required this.price,
    required this.image,
  });
}

class MenuItemCard extends StatefulWidget {
  final MenuItem item;
  final Function(MenuItem) isFavorite;

  MenuItemCard({required this.item, required this.isFavorite});

  @override
  _MenuItemCardState createState() => _MenuItemCardState();
}

class _MenuItemCardState extends State<MenuItemCard> {
  bool isFavorited = false;

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 2.0,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Image.network(
            widget.item.image,
            width: double.infinity,
            fit: BoxFit.cover,
          ),
          Padding(
            padding: EdgeInsets.all(10.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      widget.item.name,
                      style: TextStyle(
                        fontSize: 18.0,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    IconButton(
                      onPressed: () {
                        setState(() {
                          isFavorited = !isFavorited;
                          widget.isFavorite(widget.item);
                        });
                      },
                      icon: Icon(
                        isFavorited ? Icons.favorite : Icons.favorite_border,
                        color: isFavorited ? Colors.red : null,
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 5.0),
                Text(
                  widget.item.description,
                  style: TextStyle(fontSize: 14.0),
                ),
                SizedBox(height: 5.0),
                Text(
                  '\$${widget.item.price.toStringAsFixed(2)}',
                  style: TextStyle(
                    fontSize: 16.0,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class MenuItemDetailsScreen extends StatelessWidget {
  final MenuItem item;

  MenuItemDetailsScreen({required this.item});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Menu Item Details'),
      ),
      body: Padding(
        padding: EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Image.network(
              item.image,
              height: 200.0,
              width: double.infinity,
              fit: BoxFit.cover,
            ),
            SizedBox(height: 20.0),
            Text(
              item.name,
              style: TextStyle(
                fontSize: 24.0,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 10.0),
            Text(
              '\$${item.price.toStringAsFixed(2)}',
              style: TextStyle(
                fontSize: 18.0,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 10.0),
            Text(
              item.description,
              style: TextStyle(fontSize: 16.0),
            ),
          ],
        ),
      ),
    );
  }
}

class FavoritesScreen extends StatelessWidget {
  final List<MenuItem> favoriteItems;

  FavoritesScreen({required this.favoriteItems});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Favorite Menu Items'),
      ),
      body: Padding(
        padding: EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Your favorite menu items:',
              style: TextStyle(
                fontSize: 20.0,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 20.0),
            if (favoriteItems.isNotEmpty)
              Column(
                children: favoriteItems.map((item) {
                  return MenuItemCard(
                    item: item,
                    isFavorite:
                        (item) {}, // Empty function as it's not required in FavoritesScreen
                  );
                }).toList(),
              )
            else
              Text(
                'You have no favorite menu items.',
                style: TextStyle(fontSize: 16.0),
              ),
          ],
        ),
      ),
    );
  }
}

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.network(
              'https://trip-s.world/wp-content/uploads/2015/07/Mang_inasal_logo.png',
              height: 200.0,
            ),
            SizedBox(height: 20.0),
            Text(
              'Welcome to Mang Inasal!',
              style: TextStyle(
                fontSize: 24.0,
                fontWeight: FontWeight.bold,
              ),
            ),
            Text(
              'Home of Pinoy Style Barbeque',
              style: TextStyle(
                fontSize: 14.0,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class CommentManager {
  static final CommentManager _instance = CommentManager._internal();
  List<String> comments = [];

  factory CommentManager() {
    return _instance;
  }

  CommentManager._internal();
}

class FeedbackScreen extends StatefulWidget {
  @override
  _FeedbackScreenState createState() => _FeedbackScreenState();
}

class _FeedbackScreenState extends State<FeedbackScreen> {
  List<FeedbackItem> feedbackItems = [];

  @override
  void initState() {
    super.initState();
    CommentManager manager = CommentManager();
    feedbackItems = manager.comments
        .map((comment) => FeedbackItem(comment: comment))
        .toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              itemCount: feedbackItems.length,
              itemBuilder: (context, index) {
                return FeedbackCard(
                  feedbackItem: feedbackItems[index],
                  onEdit: () {
                    _editFeedback(index, feedbackItems[index]);
                  },
                  onDelete: () {
                    _deleteFeedback(index);
                  },
                );
              },
            ),
          ),
          Padding(
            padding: EdgeInsets.all(20.0),
            child: ElevatedButton(
              onPressed: () {
                _addFeedback();
              },
              child: Text('Add Feedback'),
            ),
          ),
        ],
      ),
    );
  }

  void _addFeedback() async {
    FeedbackItem? result = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => AddFeedbackScreen(
          onAddFeedback: (FeedbackItem feedback) {
            setState(() {
              feedbackItems.add(feedback);
            });
          },
        ),
      ),
    );

    if (result != null) {
      setState(() {
        feedbackItems.add(result);
      });
    }
  }

  void _editFeedback(int index, FeedbackItem feedback) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => EditFeedbackScreen(
          initialFeedback: feedback,
          onEditFeedback: (FeedbackItem updatedFeedback) {
            setState(() {
              feedbackItems[index] = updatedFeedback;
            });
          },
        ),
      ),
    );
  }

  void _deleteFeedback(int index) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Confirmation'),
          content: Text('Are you sure you want to delete this feedback?'),
          actions: <Widget>[
            TextButton(
              child: Text('Cancel'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
            TextButton(
              child: Text('Delete'),
              onPressed: () {
                setState(() {
                  feedbackItems.removeAt(index);
                  CommentManager().comments.removeAt(index);
                });
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }
}

class AddFeedbackScreen extends StatefulWidget {
  final Function(FeedbackItem) onAddFeedback;

  AddFeedbackScreen({required this.onAddFeedback});

  @override
  _AddFeedbackScreenState createState() => _AddFeedbackScreenState();
}

class _AddFeedbackScreenState extends State<AddFeedbackScreen> {
  TextEditingController _commentController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Add Feedback'),
      ),
      body: Padding(
        padding: EdgeInsets.all(20.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            TextField(
              controller: _commentController,
              decoration: InputDecoration(
                labelText: 'Comment',
              ),
            ),
            SizedBox(height: 20.0),
            ElevatedButton(
              onPressed: () {
                String comment = _commentController.text;
                FeedbackItem feedback = FeedbackItem(comment: comment);
                widget.onAddFeedback(feedback);
                CommentManager().comments.add(comment);
                Navigator.pop(context, feedback);
              },
              child: Text('Submit Feedback'),
            ),
          ],
        ),
      ),
    );
  }
}

class EditFeedbackScreen extends StatefulWidget {
  final FeedbackItem initialFeedback;
  final Function(FeedbackItem) onEditFeedback;

  EditFeedbackScreen(
      {required this.initialFeedback, required this.onEditFeedback});

  @override
  _EditFeedbackScreenState createState() => _EditFeedbackScreenState();
}

class _EditFeedbackScreenState extends State<EditFeedbackScreen> {
  late TextEditingController _commentController;

  @override
  void initState() {
    super.initState();
    _commentController =
        TextEditingController(text: widget.initialFeedback.comment);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Edit Feedback'),
      ),
      body: Padding(
        padding: EdgeInsets.all(20.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            TextField(
              controller: _commentController,
              decoration: InputDecoration(
                labelText: 'Comment',
              ),
            ),
            SizedBox(height: 20.0),
            ElevatedButton(
              onPressed: () {
                String comment = _commentController.text;
                FeedbackItem updatedFeedback = FeedbackItem(comment: comment);
                widget.onEditFeedback(updatedFeedback);
                CommentManager().comments.add(comment);
                Navigator.of(context).pop();
              },
              child: Text('Save Changes'),
            ),
          ],
        ),
      ),
    );
  }
}

class FeedbackCard extends StatelessWidget {
  final FeedbackItem feedbackItem;
  final VoidCallback onEdit;
  final VoidCallback onDelete;

  FeedbackCard(
      {required this.feedbackItem,
      required this.onEdit,
      required this.onDelete});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.all(10.0),
      child: Padding(
        padding: EdgeInsets.all(10.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              feedbackItem.comment,
              style: TextStyle(fontSize: 18.0),
            ),
            SizedBox(height: 10.0),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                IconButton(
                  icon: Icon(Icons.edit),
                  onPressed: onEdit,
                ),
                IconButton(
                  icon: Icon(Icons.delete),
                  onPressed: onDelete,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class FeedbackItem {
  final String comment;

  FeedbackItem({required this.comment});
}

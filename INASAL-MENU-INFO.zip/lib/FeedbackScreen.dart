import 'package:flutter/material.dart';

class FeedbackScreen extends StatefulWidget {
  @override
  _FeedbackScreenState createState() => _FeedbackScreenState();
}

class _FeedbackScreenState extends State<FeedbackScreen> {
  List<FeedbackItem> feedbackItems = [];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              itemCount: feedbackItems.length,
              itemBuilder: (context, index) {
                return FeedbackCard(
                  feedbackItem: feedbackItems[index],
                  onEdit: () {
                    _editFeedback(index, feedbackItems[index]);
                  },
                  onDelete: () {
                    _deleteFeedback(index);
                  },
                );
              },
            ),
          ),
          Padding(
            padding: EdgeInsets.all(20.0),
            child: ElevatedButton(
              onPressed: () {
                _addFeedback();
              },
              child: Text('Add Feedback'),
            ),
          ),
        ],
      ),
    );
  }

  void _addFeedback() async {
    FeedbackItem? result = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => AddFeedbackScreen(
          onAddFeedback: (FeedbackItem feedback) {
            setState(() {
              feedbackItems.add(feedback);
            });
          },
        ),
      ),
    );

    if (result != null) {
      setState(() {
        feedbackItems.add(result);
      });
    }
  }

  void _editFeedback(int index, FeedbackItem feedback) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => EditFeedbackScreen(
          initialFeedback: feedback,
          onEditFeedback: (FeedbackItem updatedFeedback) {
            setState(() {
              feedbackItems[index] = updatedFeedback;
            });
          },
        ),
      ),
    );
  }

  void _deleteFeedback(int index) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Confirmation'),
          content: Text('Are you sure you want to delete this feedback?'),
          actions: <Widget>[
            TextButton(
              child: Text('Cancel'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
            TextButton(
              child: Text('Delete'),
              onPressed: () {
                setState(() {
                  feedbackItems.removeAt(index);
                });
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }
}

class AddFeedbackScreen extends StatefulWidget {
  final Function(FeedbackItem) onAddFeedback;

  AddFeedbackScreen({required this.onAddFeedback});

  @override
  _AddFeedbackScreenState createState() => _AddFeedbackScreenState();
}

class _AddFeedbackScreenState extends State<AddFeedbackScreen> {
  TextEditingController _commentController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Add Feedback'),
      ),
      body: Padding(
        padding: EdgeInsets.all(20.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            TextField(
              controller: _commentController,
              decoration: InputDecoration(
                labelText: 'Comment',
              ),
            ),
            SizedBox(height: 20.0),
            ElevatedButton(
              onPressed: () {
                String comment = _commentController.text;
                FeedbackItem feedback = FeedbackItem(comment: comment);
                Navigator.pop(context, feedback);
              },
              child: Text('Submit Feedback'),
            ),
          ],
        ),
      ),
    );
  }
}

class EditFeedbackScreen extends StatefulWidget {
  final FeedbackItem initialFeedback;
  final Function(FeedbackItem) onEditFeedback;

  EditFeedbackScreen(
      {required this.initialFeedback, required this.onEditFeedback});

  @override
  _EditFeedbackScreenState createState() => _EditFeedbackScreenState();
}

class _EditFeedbackScreenState extends State<EditFeedbackScreen> {
  late TextEditingController _commentController;

  @override
  void initState() {
    super.initState();
    _commentController =
        TextEditingController(text: widget.initialFeedback.comment);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Edit Feedback'),
      ),
      body: Padding(
        padding: EdgeInsets.all(20.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            TextField(
              controller: _commentController,
              decoration: InputDecoration(
                labelText: 'Comment',
              ),
            ),
            SizedBox(height: 20.0),
            ElevatedButton(
              onPressed: () {
                String comment = _commentController.text;
                FeedbackItem updatedFeedback = FeedbackItem(comment: comment);
                widget.onEditFeedback(updatedFeedback);
                Navigator.of(context).pop();
              },
              child: Text('Save Changes'),
            ),
          ],
        ),
      ),
    );
  }
}

class FeedbackCard extends StatelessWidget {
  final FeedbackItem feedbackItem;
  final VoidCallback onEdit;
  final VoidCallback onDelete;

  FeedbackCard(
      {required this.feedbackItem,
      required this.onEdit,
      required this.onDelete});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.all(10.0),
      child: Padding(
        padding: EdgeInsets.all(10.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              feedbackItem.comment,
              style: TextStyle(fontSize: 18.0),
            ),
            SizedBox(height: 10.0),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                IconButton(
                  icon: Icon(Icons.edit),
                  onPressed: onEdit,
                ),
                IconButton(
                  icon: Icon(Icons.delete),
                  onPressed: onDelete,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class FeedbackItem {
  final String comment;

  FeedbackItem({required this.comment});
}

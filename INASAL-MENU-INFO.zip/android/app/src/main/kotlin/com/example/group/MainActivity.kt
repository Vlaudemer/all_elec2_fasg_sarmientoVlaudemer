package com.example.group

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

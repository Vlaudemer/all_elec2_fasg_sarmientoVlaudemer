package com.raywenderlich.recipe_finder

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

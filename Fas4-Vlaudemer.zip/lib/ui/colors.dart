import 'dart:ui';

const Color green = Color(0xff000000);
const Color lightGrey = Color(0xffff0000);
const Color shim = Color(0x7f000000);
